﻿using Microsoft.EntityFrameworkCore;
using PlacementService.Data.Interfaces;
using PlacementService.Models;

namespace PlacementService.Data.Repositories
{
    public class PlacementRepository : IPlacementRepository
    {
        private readonly PlacementDbContext _context;

        public PlacementRepository(PlacementDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Placement>> GetAllPlacementsAsync()
            => await _context.Placements.Include(p => p.Applications).ToListAsync();

        public async Task<Placement?> GetPlacementByIdAsync(int id)
            => await _context.Placements.Include(p => p.Applications)
                                        .FirstOrDefaultAsync(p => p.PlacementId == id);

        public async Task AddPlacementAsync(Placement placement)
            => await _context.Placements.AddAsync(placement);

        public async Task<IEnumerable<PlacementApplication>> GetApplicationsByPlacementIdAsync(int placementId)
            => await _context.PlacementApplications
                             .Where(a => a.PlacementId == placementId)
                             .ToListAsync();

        public async Task AddApplicationAsync(PlacementApplication application)
            => await _context.PlacementApplications.AddAsync(application);

        public async Task SaveAsync() => await _context.SaveChangesAsync();

        public async Task<IEnumerable<Placement>> GetPendingPlacementsAsync()
        {
            return await _context.Placements
                .Where(p => p.status == SharedServices.Models.Status.Pending)
                .ToListAsync();
        }

        public async Task<bool> ApprovePlacementAsync(int id)
        {
            var placement = await _context.Placements.FindAsync(id);
            if (placement == null) return false;

            placement.status = SharedServices.Models.Status.Approved;
            await _context.SaveChangesAsync();
            return true;
        }
    }
}

