﻿using PlacementService.Models;

namespace PlacementService.Data.Interfaces
{
    public interface IPlacementRepository
    {
        Task<IEnumerable<Placement>> GetAllPlacementsAsync();
        Task<Placement?> GetPlacementByIdAsync(int id);
        Task AddPlacementAsync(Placement placement);

        Task<IEnumerable<PlacementApplication>> GetApplicationsByPlacementIdAsync(int placementId);
        Task AddApplicationAsync(PlacementApplication application);
        Task SaveAsync();

        Task<IEnumerable<Placement>> GetPendingPlacementsAsync();
        Task<bool> ApprovePlacementAsync(int id);

    }
}