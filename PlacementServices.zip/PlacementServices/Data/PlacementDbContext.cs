﻿using Microsoft.EntityFrameworkCore;
using PlacementService.Models;

namespace PlacementService.Data
{
    public class PlacementDbContext : DbContext
    {
        public PlacementDbContext(DbContextOptions<PlacementDbContext> options) : base(options) { }

        public DbSet<Placement> Placements { get; set; }
        public DbSet<PlacementApplication> PlacementApplications { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<PlacementApplication>()
                .Property(p => p.Status)
                .HasConversion<string>();

            modelBuilder.Entity<Placement>()
                .HasMany(p => p.Applications)
                .WithOne(a => a.Placement)
                .HasForeignKey(a => a.PlacementId);
        }
    }
}
