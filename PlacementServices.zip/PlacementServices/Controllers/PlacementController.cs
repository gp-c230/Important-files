﻿using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PlacementService.Data.Interfaces;
using PlacementService.Models;
using SharedServices.Models;

namespace PlacementService.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class PlacementController : ControllerBase
    {
        private readonly IPlacementRepository _repo;
        private readonly IMapper _mapper;

        public PlacementController(IPlacementRepository repo, IMapper mapper)
        {
            _repo = repo;
            _mapper = mapper;
        }


        [HttpGet]
        public async Task<IActionResult> GetPlacements()
        {
            var placements = await _repo.GetAllPlacementsAsync();

            // Filter placements where status is Approved
            var approvedPlacements = placements
                .Where(p => p.status == Status.Approved);

            return Ok(_mapper.Map<IEnumerable<Placement>>(approvedPlacements));
        }



        [Authorize(Roles ="Faculty")]
        [HttpPost("post-job")]
        public async Task<IActionResult> PostJob([FromBody] Placement dto)
        {
            var placement = _mapper.Map<Placement>(dto);
            await _repo.AddPlacementAsync(placement);
            await _repo.SaveAsync();
            return Ok("Placement posted successfully.");
        }
        [Authorize(Roles ="Student")]
        [HttpPost("apply")]
        public async Task<IActionResult> Apply([FromBody] PlacementApplication dto)
        {
            var application = _mapper.Map<PlacementApplication>(dto);
            application.Status = Status.Pending;
            await _repo.AddApplicationAsync(application);
            await _repo.SaveAsync();
            return Ok("Application submitted.");
        }

        [HttpGet("{id}/applications")]
        public async Task<IActionResult> GetApplications(int id)
        {
            var apps = await _repo.GetApplicationsByPlacementIdAsync(id);
            return Ok(_mapper.Map<IEnumerable<PlacementApplication>>(apps));
        }

        [HttpGet("pending")]
        public async Task<IActionResult> GetPendingPlacements()
        {
            var placements = await _repo.GetPendingPlacementsAsync();
            return Ok(placements);
        }

        [Authorize(Roles = "Admin")]
        [HttpPut("approve/{id}")]
        public async Task<IActionResult> ApprovePlacement(int id)
        {
            var result = await _repo.ApprovePlacementAsync(id);
            return result ? Ok("Placement approved") : NotFound("Placement not found");
        }

    }
}