﻿using AutoMapper;
using PlacementService.Models;

namespace PlacementService.Mappings
{
    public class PlacementProfile : Profile
    {
        public PlacementProfile()
        {
            CreateMap<Placement, Placement>().ReverseMap();
            CreateMap<PlacementApplication, PlacementApplication>().ReverseMap();
        }
    }
}