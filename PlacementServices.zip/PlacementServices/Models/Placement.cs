﻿using System.Text.Json.Serialization;
using SharedServices.Models;

namespace PlacementService.Models
{
    public class Placement
    {
        public int PlacementId { get; set; }
        public string CompanyName { get; set; } = "";
        public string Role { get; set; } = "";
        public int CTC { get; set; }
        public DateTime LastDateToApply { get; set; }
        public Status status { get; set; } = Status.Pending;


        [JsonIgnore]
        public ICollection<PlacementApplication> Applications { get; set; } = new List<PlacementApplication>();
    }
}