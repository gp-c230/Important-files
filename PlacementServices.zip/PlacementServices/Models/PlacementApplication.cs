﻿using SharedServices.Models;

namespace PlacementService.Models
{
    public class PlacementApplication
    {
        public int PlacementApplicationId { get; set; }
        public int PlacementId { get; set; }
        public string StudentEmail { get; set; } = "";
        public Status Status { get; set; } = Status.Pending;

        public Placement Placement { get; set; } = null!;
    }
}