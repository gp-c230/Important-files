﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace PlacementServices.Migrations
{
    /// <inheritdoc />
    public partial class stat : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "status",
                table: "Placements",
                type: "int",
                nullable: false,
                defaultValue: 0);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "status",
                table: "Placements");
        }
    }
}
