﻿using SharedServices.Models;
using System.Text.Json.Serialization;

namespace EventService.Models
{
    public class Event
    {
        public int EventId { get; set; }
        public string Title { get; set; } = "";
        public string Description { get; set; } = "";
        public DateTime EventDate { get; set; }
        public string Location { get; set; } = "";

        public Status Status { get; set; } 

        [JsonIgnore]
        public ICollection<EventRegistration> Registrations { get; set; } = new List<EventRegistration>();
    }
}