﻿using SharedServices.Models;

namespace EventService.Models
{
    public class EventRegistration
    {
        public int EventRegistrationId { get; set; }
        public int EventId { get; set; }
        public string StudentEmail { get; set; } = "";
        public Status Status { get; set; } = Status.Pending;

        public Event Event { get; set; } = null!;
    }
}
