﻿using AutoMapper;
using EventService.Models;

namespace EventService.Mappings
{
    public class EventProfile : Profile
    {
        public EventProfile()
        {
            CreateMap<Event, Event>().ReverseMap();
            CreateMap<EventRegistration, EventRegistration>().ReverseMap();
        }
    }
}