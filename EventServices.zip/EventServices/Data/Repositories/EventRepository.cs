﻿using Microsoft.EntityFrameworkCore;
using EventService.Data.Interfaces;
using EventService.Models;
using SharedServices.Models;

namespace EventService.Data.Repositories
{
    public class EventRepository : IEventRepository
    {
        private readonly EventDbContext _context;

        public EventRepository(EventDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Event>> GetAllEventsAsync()
            => await _context.Events.Include(e => e.Registrations).ToListAsync();

        public async Task<Event?> GetEventByIdAsync(int id)
            => await _context.Events.Include(e => e.Registrations)
                                    .FirstOrDefaultAsync(e => e.EventId == id);

        public async Task AddEventAsync(Event e)
            => await _context.Events.AddAsync(e);


        public async Task CreatedEventAsync(Event ev)
        {
            _context.Events.Add(ev);
            await _context.SaveChangesAsync();
        }


        public async Task<IEnumerable<Event>> GetEventsByStatusAsync(Status status)
        {
            return await _context.Events
                .Where(e => e.Status == status)
                .Include(e => e.Registrations)
                .ToListAsync();
        }

        public async Task<bool> UpdateEventStatusAsync(int eventId, Status newStatus)
        {
            // 1. Find the event in the database by its ID
            var eventToUpdate = await _context.Events.FindAsync(eventId);

            // 2. If the event is not found, return false (indicating failure)
            if (eventToUpdate == null)
            {
                return false;
            }

            // 3. Update the 'Status' property of the found event
            eventToUpdate.Status = newStatus;

            // 4. Save the changes to the database
            await _context.SaveChangesAsync();

            // 5. Return true (indicating success)
            return true;
        }






        //public async Task<IEnumerable<EventRegistration>> GetRegistrationsAsync(int eventId)
        //    => await _context.EventRegistrations
        //                     .Where(r => r.EventId == eventId)
        //                     .ToListAsync();

        public async Task AddRegistrationAsync(EventRegistration reg)
            => await _context.EventRegistrations.AddAsync(reg);

        public async Task SaveAsync() => await _context.SaveChangesAsync();
    }
}