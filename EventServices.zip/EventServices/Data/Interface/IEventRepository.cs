﻿using EventService.Models;
using SharedServices.Models;

namespace EventService.Data.Interfaces
{
    public interface IEventRepository
    {
        Task<IEnumerable<Event>> GetAllEventsAsync();
        Task<Event?> GetEventByIdAsync(int id);
        Task AddEventAsync(Event e);

        Task<IEnumerable<Event>> GetEventsByStatusAsync(Status status);

        Task<bool> UpdateEventStatusAsync(int eventId, Status newStatus);
        Task CreatedEventAsync(Event ev);

        //Task<IEnumerable<EventRegistration>> GetRegistrationsByEventIdAsync(int eventId);
        Task AddRegistrationAsync(EventRegistration reg);
        Task SaveAsync();
    }
}
