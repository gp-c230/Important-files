﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using EventService.Data.Interfaces;
using EventService.Models;
using SharedServices.Models;
using Microsoft.AspNetCore.Authorization;

namespace EventService.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class EventController : ControllerBase
    {
        private readonly IEventRepository _repo;
        private readonly IMapper _mapper;

        public EventController(IEventRepository repo, IMapper mapper)
        {
            _repo = repo;
            _mapper = mapper;
        }

        [HttpGet]
        public async Task<IActionResult> GetEvents()
        {
            var events = await _repo.GetAllEventsAsync();
            return Ok(_mapper.Map<IEnumerable<EventDto>>(events));
        }
        [Authorize(Roles = "Faculty")]
        [HttpPost("create")]
        public async Task<IActionResult> Create([FromBody] Event dto)
        {
            var e = _mapper.Map<Event>(dto);
            e.Status = Status.Pending;
            await _repo.AddEventAsync(e);
            await _repo.SaveAsync();
            return Ok("Event created and sent for Approval.");
        }
        [Authorize(Roles = "Student")]
        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] EventRegistration dto)
        {
            var reg = _mapper.Map<EventRegistration>(dto);
            reg.Status = Status.Pending;
            await _repo.AddRegistrationAsync(reg);
            await _repo.SaveAsync();
            return Ok("Registration submitted.");
        }


        [HttpGet("approved")]
        [Authorize(Roles = "Student")]
        public async Task<IActionResult> GetApprovedEvents()
        {
            var events = await _repo.GetEventsByStatusAsync(Status.Approved);
            return Ok(_mapper.Map<IEnumerable<Event>>(events));
        }
        //[HttpGet("registrations")]
        //public async Task<IActionResult> GetRegistrations()
        //{
        //    var regs = await _repo.GetRegistrations();
        //    return Ok(_mapper.Map<IEnumerable<EventRegistration>>(regs));
        //}

        [Authorize(Roles = "Admin")]
        [HttpGet("pending")]
        public async Task<IActionResult> GetPendingEvents()
        {
            var events = await _repo.GetEventsByStatusAsync(Status.Pending);
            return Ok(_mapper.Map<IEnumerable<Event>>(events));
        }


        [Authorize(Roles = "Admin")] // Only allow users with "Admin" role to access this
        [HttpPut("approve/{id}")] // This route matches what your AdminService is calling
        public async Task<IActionResult> ApproveEvent(int id)
        {
            // Call the repository method to update the event's status to Approved
            var success = await _repo.UpdateEventStatusAsync(id, Status.Approved);

            if (success)
            {
                // If update was successful, return 200 OK
                return Ok($"Event with ID {id} approved successfully.");
            }
            else
            {
                // If event not found or update failed, return 404 Not Found (or 400 Bad Request)
                // 404 is more appropriate if the ID doesn't correspond to an existing event.
                return NotFound($"Event with ID {id} not found or failed to approve.");
            }

        }
    }
}
