﻿using Microsoft.Extensions.Configuration;

using Microsoft.IdentityModel.Tokens;

using System.IdentityModel.Tokens.Jwt;

using System.Security.Claims;

using System.Text;

using UserService.Models;

namespace UserService.Services

{

    public class JwtService

    {

        private readonly string _secret;

        private readonly string _issuer;

        private readonly string _audience;

        private readonly int _duration;

        public JwtService(IConfiguration config)

        {

            _secret = config["Jwt:Key"];

            _issuer = config["Jwt:Issuer"];

            _audience = config["Jwt:Audience"];

            _duration = int.Parse(config["Jwt:DurationInMinutes"]);

        }

        public string GenerateToken(User user)

        {

            var claims = new[]

            {

            new Claim(JwtRegisteredClaimNames.Sub, user.UserId.ToString()),

            new Claim(JwtRegisteredClaimNames.Email, user.Email),

            new Claim("fullname", user.Name),

            new Claim(ClaimTypes.Role, user.Role),

            new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString())

        };

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_secret));

            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(

                issuer: _issuer,

                audience: _audience,

                claims: claims,

                expires: DateTime.Now.AddMinutes(_duration),

                signingCredentials: creds

            );

            return new JwtSecurityTokenHandler().WriteToken(token);

        }

    }

}

