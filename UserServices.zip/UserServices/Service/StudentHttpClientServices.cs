﻿using SharedServices.Models;
using System.Net.Http.Json;
using UserServices.DTOs; // shared DTO

public class StudentHttpClientServices
{
    private readonly HttpClient _http;

    public StudentHttpClientServices(HttpClient http)
    {
        _http = http;
    }

    public async Task<bool> CreateStudentAsync(StudentDto dto)
    {
        var response = await _http.PostAsJsonAsync("http://localhost:5073/api/student", dto);
        return response.IsSuccessStatusCode;
    }
}