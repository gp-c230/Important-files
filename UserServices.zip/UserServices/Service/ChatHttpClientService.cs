﻿using CommonModels.Models;
using System.Net.Http.Headers;

public class ChatHttpClientService
{
    private readonly HttpClient _http;
    private readonly IHttpContextAccessor _context;

    public ChatHttpClientService(HttpClient http, IHttpContextAccessor context)
    {
        _http = http;
        _context = context;
    }

    public async Task<bool> SendMessageAsync(ChatDTO message)
    {
        var token = _context.HttpContext?.Request.Headers["Authorization"].ToString()?.Replace("Bearer ", "");
        if (!string.IsNullOrWhiteSpace(token))
            _http.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

        var response = await _http.PostAsJsonAsync("http://localhost:5076/api/chat/send", message);
        return response.IsSuccessStatusCode;
    }

    public async Task<List<ChatDTO>> GetUserMessagesAsync(string userId)
    {
        var token = _context.HttpContext?.Request.Headers["Authorization"].ToString()?.Replace("Bearer ", "");
        if (!string.IsNullOrWhiteSpace(token))
            _http.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

        var response = await _http.GetAsync($"http://localhost:5076/api/chat/user/{userId}");
        return await response.Content.ReadFromJsonAsync<List<ChatDTO>>() ?? new List<ChatDTO>();
    }
}