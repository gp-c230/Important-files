﻿using SharedServices.Models;
using StudentService.Models;
using System.Security.Cryptography;
using System.Text;
using UserService.Data;
using UserService.Data.Interfaces;
using UserService.Models;
using UserServices.DTOs;


namespace UserService.Services
{
    public class AuthService
    {
        private readonly IUserRepository _repository;
        private readonly StudentHttpClientServices _studentHttp;

        public AuthService(IUserRepository repository, StudentHttpClientServices studentHttp)
        {
            _repository = repository;
            _studentHttp = studentHttp;
        }

        public async Task<User> RegisterAsync(RegisterDto dto)
        {
            var hashedPassword = HashPassword(dto.Password);
            var user = new User
            {
                Name = dto.Name,
                Email = dto.Email,
                PasswordHash = hashedPassword,
                Role = dto.Role ?? "Student",
                Status = dto.Role == "Student" ? Status.Pending : Status.Approved,
            };
            await _repository.AddAsync(user);
            await _repository.SaveAsync();

            if (user.Role == "Student")
            {
                var studentDto = new StudentDto
                {
                    StudentId = user.UserId,
                    Name = user.Name,
                    Email = user.Email,
                    Department = "", // let front-end fill or update later
                    Marks = 0,
                    Backlogs = 0,
                    Password = dto.Password,
                    Status = Status.Pending
                };

                await _studentHttp.CreateStudentAsync(studentDto);
            }

            return user;
        }
        

        public async Task<User?> LoginAsync(LoginDto dto)
        {
            var hashed = HashPassword(dto.Password);
            var user = await _repository.GetUserByEmailAndPasswordAsync(dto.Email, hashed);
            if (user == null || string.IsNullOrEmpty(user.Role) || string.IsNullOrEmpty(user.Name) || string.IsNullOrEmpty(user.Email))
                return null;
            if (user.Role == "Student" && user.Status != Status.Approved)
                return null;

            return user;
        }

        public async Task<bool> ApproveUserAsync(int userId)
        {
            var user = await _repository.GetByIdAsync(userId);
            if (user == null || user.Role != "Student") return false;
            user.Status = Status.Approved;
            await _repository.SaveAsync();
            return true;
        }
        private string HashPassword(string password)
        {
            using var sha = SHA256.Create();
            var bytes = Encoding.UTF8.GetBytes(password);
            var hash = sha.ComputeHash(bytes);
            return Convert.ToBase64String(hash);
        }

        public async Task<List<User>> GetUsersByStatusAsync()
        {
            return await _repository.GetUsersByStatusAsync(Status.Pending);
        }
    }

}