﻿using SharedServices.Models;
using UserService.Models;

namespace UserService.Data.Interfaces
{
    public interface IUserRepository
    {
        Task<User?> GetUserByEmailAndPasswordAsync(string email, string passwordHash);
        Task<IEnumerable<User>> GetAllAsync();
        Task<User?> GetByEmailAsync(string email);
        Task AddAsync(User user);

        Task<User?> GetByIdAsync(int id);
        Task<List<User>> GetUsersByStatusAsync(Status status);
        Task SaveAsync();
    }
}