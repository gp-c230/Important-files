﻿namespace UserServices.DTOs
{
    public class RegisterDto
    {
        public int UserId { get; set; }
        public string Role { get; set; } = ""; // "Student", "Admin", "Faculty"
        public string Name { get; set; } = "";
        public string Email { get; set; } = "";
        public string Password { get; set; } = "";
    }
}
