﻿using Microsoft.AspNetCore.Authorization;
using System.Security.Claims;
using Microsoft.AspNetCore.Mvc;
using UserService.Services;
using UserServices.DTOs;

namespace UserService.Controllers

{

    [ApiController]

    [Route("api/[controller]")]

    public class UserController : ControllerBase

    {

        private readonly AuthService _service;

        public UserController(AuthService service)

        {

            _service = service;
        }
        [HttpPost("register")]

        public async Task<IActionResult> Register(RegisterDto dto)

        {

            var user =await _service.RegisterAsync(dto);

            return Ok(user);
        }
        [HttpPost("login")]

        public async Task<IActionResult> Login(LoginDto dto, [FromServices] JwtService jwtService)

        {

            var user = await _service.LoginAsync(dto);

            if (user == null)

                return Unauthorized(new { message = "Invalid email or password" });

            var token = jwtService.GenerateToken(user);

            return Ok(new

            {

                token,

                user = new

                {

                    user.UserId,

                    user.Name,

                    user.Email,

                    user.Role

                }

            });

        }

        [Authorize]

        [HttpGet("me")]

        public IActionResult GetProfile()

        {

            var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;

            return Ok(new { userId });

        }


        [Authorize(Roles = "Admin")]
        [HttpPut("internal/user/approve/{userId}")]
        public async Task<IActionResult> ApproveUser(int userId)
        {
            Console.WriteLine($"[UserController] Approving user with ID: {userId}");

            try
            {
                var success = await _service.ApproveUserAsync(userId);
                if (!success)
                {
                    Console.WriteLine($"[UserController] User ID {userId} not found or already approved.");
                    return NotFound("Student not found or already approved.");
                }

                return Ok("Student approved in UserService.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[UserController] Exception while approving user: {ex.Message}");
                return StatusCode(500, "Internal server error while approving user.");
            }
            //var success = await _service.ApproveUserAsync(userId);
            //if (!success) return NotFound("Student not found or already approved.");
            //return Ok("Student approved in UserService.");
        }

        //[Authorize(Roles = "Admin")]
        //[HttpGet("Pending")]
        //public async Task<IActionResult> GetPendingUsers()
        //{
        //    var pendingUser = await _service.GetUsersByStatusAsync();
        //    return Ok(pendingUser);
        //}

        [Authorize(Roles = "Admin")]
        [HttpGet("Pending")]
        public async Task<IActionResult> GetPendingUsers()
        {
            try
            {
                Console.WriteLine("[UserController] GetPendingUsers() called");

                var pendingUser = await _service.GetUsersByStatusAsync();

                Console.WriteLine($"[UserController] Fetched {pendingUser?.Count() ?? 0} users");

                return Ok(pendingUser);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[UserController] ERROR: {ex.Message}");
                return StatusCode(500, "Internal error in GetPendingUsers.");
            }
        }
    }

}

