﻿using AutoMapper;
using UserService.Models;

namespace UserService.Mappings
{
    public class UserProfile : Profile
    {
        public UserProfile()
        {
            CreateMap<User, User>().ReverseMap();
        }
    }
}
