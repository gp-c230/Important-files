﻿
using SharedServices.Models;

public class User
    {
        public int UserId { get; set; }
        public string Role { get; set; } = ""; // "Student", "Admin", "Faculty"
        public string Name { get; set; } = "";
        public string Email { get; set; } = "";
        public string PasswordHash { get; set; } = "";

        public Status Status { get; set; } = Status.Pending;

    }
