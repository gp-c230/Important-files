﻿using AutoMapper;
using SharedService.Models;

namespace SharedService.Mappings
{
    public class AdminProfile : Profile
    {
        public AdminProfile()
        {
            CreateMap<Student, Student>().ReverseMap();
            CreateMap<Admin, Admin>().ReverseMap();
        }
    }
}