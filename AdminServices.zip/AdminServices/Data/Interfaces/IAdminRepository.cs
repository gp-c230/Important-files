﻿using AdminService.Models;
using SharedService.Models;
using SharedServices.Models;

namespace SharedService.Data.Interfaces
{
    public interface IAdminRepository
    {
        Task<Admin?> GetAdminByEmailAsync(string email);
        Task<Student?> GetStudentByIdAsync(int id);
        Task<IEnumerable<Student>> GetPendingStudentsAsync();
        Task AddStudentAsync(Student student);

        Task SaveAsync();

        // IAdminRepository.cs
        Task<Faculty> AddFacultyAsync(Faculty faculty);
        Task<IEnumerable<Faculty>> GetAllFacultiesAsync();
        Task<Faculty> GetFacultyByIdAsync(int id);

        //Task<bool> UpdateEventStatusAsync(int id, Status status);

    }
}
