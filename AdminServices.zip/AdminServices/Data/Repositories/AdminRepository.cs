﻿using SharedService.Data.Interfaces;
using SharedService.Models;
using Microsoft.EntityFrameworkCore;
using AdminService.Models;
using PlacementService.Models;

namespace SharedService.Data.Repositories
{
    public class AdminRepository : IAdminRepository
    {
        private readonly AdminDbContext _context;

        public AdminRepository(AdminDbContext context)
        {
            _context = context;
        }

        public async Task<Admin?> GetAdminByEmailAsync(string email)
            => await _context.Admins.FirstOrDefaultAsync(a => a.Email == email);

        public async Task<Student?> GetStudentByIdAsync(int id)
            => await _context.Students.FindAsync(id);

        public async Task<IEnumerable<Student>> GetPendingStudentsAsync()
            => await _context.Students.Where(s => s.Status == SharedServices.Models.Status.Pending).ToListAsync();

        public async Task AddStudentAsync(Student student)
            => await _context.Students.AddAsync(student);

        public async Task SaveAsync() => await _context.SaveChangesAsync();


        public async Task<Faculty> AddFacultyAsync(Faculty faculty)
        {
            _context.Faculties.Add(faculty);
            await _context.SaveChangesAsync();
            return faculty;
        }
        public async Task<IEnumerable<Faculty>> GetAllFacultiesAsync()
        {
            return await _context.Faculties.ToListAsync();
        }
        public async Task<Faculty> GetFacultyByIdAsync(int id)
        {
            return await _context.Faculties.FindAsync(id);
        }

        public async Task<IEnumerable<Placement>> GetPendingPlacementsAsync() => await _context.Placements
            .Where(p => p.status == SharedServices.Models.Status.Pending).ToListAsync();


    }
}

