﻿using SharedService.Data.Interfaces;
using AdminServices.Services;
using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using AdminService.Models;
using SharedServices.Models;

namespace SharedService.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize(Roles = "Admin")]
    
    public class AdminController : ControllerBase
    {
        private readonly IAdminRepository _repo;
        private readonly IMapper _mapper;
        private readonly UserHttpClientService _userService;
        private readonly StudentHttpClientService _studentService;
        private readonly PostHttpClientService _postService;
        private readonly PlacementHttpService _placementClient;

        public AdminController(IAdminRepository repo, IMapper mapper, UserHttpClientService userService, StudentHttpClientService studentService, PostHttpClientService postService, PlacementHttpService placementService)
        {
            _repo = repo;
            _mapper = mapper;
            _userService = userService;
            _studentService = studentService;
            _postService = postService;
            _placementClient = placementService;
        }
        [HttpGet("students/pending")]
        public async Task<IActionResult> GetPendingStudents()
        {
            var students = await _studentService.GetPendingStudentsAsync();
            return Ok(students);
        }

        [HttpPut("students/approve/{id}")]
        public async Task<IActionResult> ApproveStudentRegister(int id)
        {
            var success = await _studentService.ApproveStudentAsync(id);
            if (!success)
                return StatusCode(500, "Failed to approve student via StudentService");

            return Ok(new { message = "Student approved successfully" });
        }


        [Authorize(Roles = "Admin")]
        [HttpPut("approve-event/{id}")]
        public async Task<IActionResult> ApproveEvent(int id, [FromServices] EventHttpClientService eventClient)
        {
            var result = await eventClient.ApproveEventAsync(id);
            return result ? Ok("Event approved by Admin") : BadRequest("Failed to approve event");
        }


        [Authorize(Roles = "Admin")]
        [HttpGet("pending-events")]
        public async Task<IActionResult> GetPendingEvents([FromServices] EventHttpClientService client)
        {
            var events = await client.GetPendingEventsAsync();
            return Ok(events);
        }


        //[HttpPut("Posts/approve/{id}")]
        //public async Task<IActionResult> ApprovePost(int id)
        //{
        //    var student = await _postService.ApprovePostAsync(id);
        //    if (!student) return NotFound("Post not found");


        //    return Ok("Post approved.");
        //}

        [HttpPost("faculty")]
        public async Task<IActionResult> AddFaculty([FromBody] Faculty faculty)
        {
            if (faculty == null)
                return BadRequest("Invalid faculty data.");

            var created = await _repo.AddFacultyAsync(faculty);
            return CreatedAtAction(nameof(AddFaculty), new { id = created.Id }, created);
        }

        //[HttpGet("faculty")]
        //public async Task<IActionResult> GetAllFaculties()
        //{
        //    var faculties = await _repo.GetAllFacultiesAsync();
        //    return Ok(faculties);
        //}

        [Authorize(Roles = "Admin")]
        [HttpGet("faculties")]
        public async Task<IActionResult> GetFaculties()
        {
            var faculties = await _repo.GetAllFacultiesAsync();
            return Ok(faculties);
        }

        [Authorize(Roles = "Admin")]
        [HttpGet("pending-posts")]
        public async Task<IActionResult> GetPendingPosts()
        {
            var posts = await _postService.GetPendingPostsAsync();
            return Ok(posts);
        }

        [Authorize(Roles = "Admin")]
        [HttpPut("approve-post/{id}")]
        public async Task<IActionResult> ApprovePost(int id)
        {
            var success = await _postService.ApprovePostAsync(id);
            if (!success) return BadRequest("Failed to approve post");

            return Ok("Post approved");
        }

        [Authorize]
        [HttpGet("conversation")]
        public async Task<IActionResult> GetChatConversation([FromQuery] string user1,[FromQuery] string user2,[FromServices] ChatHttpClientService chatClient)
        {
            var messages = await chatClient.GetConversationAsync(user1, user2);
            return Ok(messages);
        }

        [HttpGet("pending")]
        public async Task<IActionResult> GetPendingPlacements()
        {
            var placements = await _placementClient.GetPendingPlacementsAsync();
            return Ok(placements);
        }

        [HttpPut("approve/{id}")]
        public async Task<IActionResult> ApprovePlacement(int id)
        {
            var result = await _placementClient.ApprovePlacementAsync(id);
            return result ? Ok("Placement approved") : BadRequest("Approval failed");
        }

    }
}