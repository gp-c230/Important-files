﻿using SharedServices.Models;

namespace SharedService.Models
{
    public class Student
    {
        public int StudentId { get; set; }
        public string Name { get; set; } = "";
        public string Email { get; set; } = "";
        public string Department { get; set; } = "";
        public int Marks { get; set; }
        public int Backlogs { get; set; }
        public string Password { get; set; } = "";
        public Status Status { get; set; }
    }
}
