﻿using PlacementService.Models;

namespace AdminServices.Services
{
    public class PlacementHttpService
    {
        
        private readonly HttpClient _httpClient;

        public PlacementHttpService(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public async Task<IEnumerable<Placement>> GetPendingPlacementsAsync()
        {
            var response = await _httpClient.GetAsync("http://localhost:5252/api/Placement/pending");
            response.EnsureSuccessStatusCode();
            return await response.Content.ReadFromJsonAsync<IEnumerable<Placement>>();
        }

        public async Task<bool> ApprovePlacementAsync(int id)
        {
            var response = await _httpClient.PutAsync($"https://localhost:5252/api/placements/approve/{id}", null);
            return response.IsSuccessStatusCode;
        }

    }
}
