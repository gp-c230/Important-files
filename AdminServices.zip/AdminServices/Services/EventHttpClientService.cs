﻿using SharedServices.Models;
using System.Net.Http.Headers;
using System.Net.Http.Json;

public class EventHttpClientService
{
    private readonly HttpClient _httpClient;
    private readonly IHttpContextAccessor _context;

    public EventHttpClientService(HttpClient httpClient, IHttpContextAccessor context)
    {
        _httpClient = httpClient;
        _context = context;
    }

    public async Task<bool> ApproveEventAsync(int eventId)
    {
        var token = _context.HttpContext?.Request.Headers["Authorization"].ToString()?.Replace("Bearer ", "");

        if (!string.IsNullOrWhiteSpace(token))
        {
            _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
        }

        var url = $"http://localhost:5094/api/event/approve/{eventId}"; // Update port if different

        var response = await _httpClient.PutAsync(url, null);
        return response.IsSuccessStatusCode;
    }

    public async Task<List<EventDto>> GetPendingEventsAsync()
    {
        var token = _context.HttpContext?.Request.Headers["Authorization"].ToString()?.Replace("Bearer ", "");
        if (!string.IsNullOrEmpty(token))
            _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

        var response = await _httpClient.GetAsync("http://localhost:5094/api/event/pending");
        return await response.Content.ReadFromJsonAsync<List<EventDto>>() ?? new();
    }

}