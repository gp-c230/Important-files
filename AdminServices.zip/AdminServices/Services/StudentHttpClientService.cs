﻿
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text.Json;

using SharedServices.Models;


namespace AdminServices.Services
{
    public class StudentHttpClientService
    {
        private readonly HttpClient _http;
        private readonly IHttpContextAccessor _accessor;

        public StudentHttpClientService(HttpClient http, IHttpContextAccessor accessor)
        {
            _http = http;
            _accessor = accessor;
        }

        public async Task<bool> ApproveStudentAsync(int id)
        {
            // Forward token from original request
            var token = _accessor.HttpContext?.Request.Headers["Authorization"].ToString();

            if (!string.IsNullOrEmpty(token))
            {
                // Remove 'Bearer ' if it exists, or clean up the token
                var cleanToken = token.Replace("Bearer ", ""); 
                _http.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", cleanToken);
            }

            var response = await _http.PutAsync($"http://localhost:5073/api/student/approve/{id}", null);
            return response.IsSuccessStatusCode;
        }



        public async Task<bool> ApproveUserInUserserviceAsync(int id)
        {
            var token = _accessor.HttpContext?.Request.Headers["Authorization"].ToString();
            if (!string.IsNullOrEmpty(token))
                _http.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token.Replace("Bearer ", ""));

            var response = await _http.PutAsync($"http://localhost:5260/internal/user/approve/{id}", null); // ✅ only internal
            return response.IsSuccessStatusCode;
        }

        public async Task<List<StudentDto>> GetPendingStudentsAsync()
        {
            var response = await _http.GetAsync("http://localhost:5073/api/student/pending");
            var json = await response.Content.ReadAsStringAsync();
            Console.WriteLine("RAW JSON FROM SS");
            Console.WriteLine(json);
            if (!response.IsSuccessStatusCode)
                return new List<StudentDto>();
            //var data = JsonSerializer.Deserialize<List<StudentDto>>(json);
            var data = await response.Content.ReadFromJsonAsync<List<StudentDto>>();
            return data ?? new List<StudentDto>();
        }


    }
}
