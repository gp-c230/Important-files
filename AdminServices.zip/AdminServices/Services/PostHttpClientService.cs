﻿using System.Net.Http.Headers;
using System.Text.Json;
using SharedServices.Models;

public class PostHttpClientService
{
    private readonly HttpClient _http;
    private readonly IHttpContextAccessor _context;

    public PostHttpClientService(HttpClient http, IHttpContextAccessor context)
    {
        _http = http;
        _context = context;
    }

    public async Task<bool> ApprovePostAsync(int postId)
    {
        var token = _context.HttpContext?.Request.Headers["Authorization"].ToString()?.Replace("Bearer ", "");

        if (!string.IsNullOrEmpty(token))
            _http.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

        var response = await _http.PutAsync($"http://localhost:5278/api/post/approve/{postId}?status=Approved", null);

        return response.IsSuccessStatusCode;
    }

    public async Task<IEnumerable<PostDTO>?> GetPendingPostsAsync()
    {
        // ✅ Extract Bearer token from the request
        var token = _context.HttpContext?.Request.Headers["Authorization"].ToString().Replace("Bearer ", "");

        if (string.IsNullOrEmpty(token))
            return null;

        _http.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

        // ✅ Call the PostService endpoint directly
        var response = await _http.GetAsync($"http://localhost:5278/api/post/pending-posts");

        if (!response.IsSuccessStatusCode)
            return null;

        var json = await response.Content.ReadAsStringAsync();

        return JsonSerializer.Deserialize<IEnumerable<PostDTO>>(json, new JsonSerializerOptions
        {
            PropertyNameCaseInsensitive = true
        });
    }
}