﻿namespace ChatService.Models
{
    public class ChatMessage
    {
        public int ChatMessageId { get; set; }
        public string SenderEmail { get; set; } = "";
        public string ReceiverEmail { get; set; } = "";
        public string Message { get; set; } = "";
        public DateTime Timestamp { get; set; } = DateTime.UtcNow;
    }
}