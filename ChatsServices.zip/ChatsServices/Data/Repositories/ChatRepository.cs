﻿using ChatService.Data.Interfaces;
using ChatService.Models;
using Microsoft.EntityFrameworkCore;

namespace ChatService.Data.Repositories
{
    public class ChatRepository : IChatRepository
    {
        private readonly ChatDbContext _context;

        public ChatRepository(ChatDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<ChatMessage>> GetConversationAsync(string user1, string user2)
        {
            return await _context.ChatMessages
                .Where(m =>
                    (m.SenderEmail == user1 && m.ReceiverEmail == user2) ||
                    (m.SenderEmail == user2 && m.ReceiverEmail == user1))
                .OrderBy(m => m.Timestamp)
                .ToListAsync();
        }

        public async Task AddMessageAsync(ChatMessage message)
        {
            await _context.ChatMessages.AddAsync(message);
        }

        public async Task SaveAsync() => await _context.SaveChangesAsync();
    }
}