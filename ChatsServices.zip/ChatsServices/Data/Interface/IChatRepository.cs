﻿using ChatService.Models;

namespace ChatService.Data.Interfaces
{
    public interface IChatRepository
    {
        Task<IEnumerable<ChatMessage>> GetConversationAsync(string user1, string user2);
        Task AddMessageAsync(ChatMessage message);
        Task SaveAsync();
    }
}