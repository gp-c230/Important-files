﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using ChatService.Data.Interfaces;
using ChatService.Models;
using Microsoft.AspNetCore.Authorization;

namespace ChatService.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ChatController : ControllerBase
    {
        private readonly IChatRepository _repo;
        private readonly IMapper _mapper;

        public ChatController(IChatRepository repo, IMapper mapper)
        {
            _repo = repo;
            _mapper = mapper;
        }

        [Authorize]
        [HttpPost("send")]
        public async Task<IActionResult> SendMessage([FromBody] ChatMessage dto)
        {
            var message = _mapper.Map<ChatMessage>(dto);
            message.Timestamp = DateTime.UtcNow;

            await _repo.AddMessageAsync(message);
            await _repo.SaveAsync();

            return Ok("Message sent.");
        }

        [Authorize]
        [HttpGet("conversation")]
        public async Task<IActionResult> GetConversation([FromQuery]string user1,[FromQuery] string user2)
        {
            var messages = await _repo.GetConversationAsync(user1, user2);
            return Ok(_mapper.Map<IEnumerable<ChatMessage>>(messages));
        }
    }
}