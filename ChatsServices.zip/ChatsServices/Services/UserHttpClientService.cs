﻿using MediaBrowser.Model.Dto;

public class UserHttpClientService
{
    private readonly HttpClient _http;

    public UserHttpClientService(HttpClient http)
    {
        _http = http;
    }

    public async Task<UserDto?> GetUserByIdAsync(string id)
    {
        var response = await _http.GetAsync($"http://localhost:5260/api/user/{id}");
        if (!response.IsSuccessStatusCode)
            return null;

        return await response.Content.ReadFromJsonAsync<UserDto>();
    }
}