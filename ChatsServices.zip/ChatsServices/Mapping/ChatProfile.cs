﻿using AutoMapper;
using ChatService.Models;

namespace ChatService.Mappings
{
    public class ChatProfile : Profile
    {
        public ChatProfile()
        {
            CreateMap<ChatMessage, ChatMessage>().ReverseMap();
        }
    }
}