﻿using Microsoft.EntityFrameworkCore;
using StudentService.Data.Interfaces;
using StudentService.Models;

namespace StudentService.Data.Repositories
{
    public class StudentRepository : IStudentRepository
    {
        private readonly StudentDbContext _context;

        public StudentRepository(StudentDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Student>> GetAllAsync() => await _context.Students.ToListAsync();

        public async Task<Student?> GetByIdAsync(int id) => await _context.Students.FindAsync(id);

        public async Task<Student?> GetByEmailAsync(string email) =>
            await _context.Students.FirstOrDefaultAsync(s => s.Email == email);

        public async Task AddAsync(Student student) => await _context.Students.AddAsync(student);

        public async Task SaveAsync() => await _context.SaveChangesAsync();
    }
}
