﻿using System.Net.Http.Headers;
using System.Net.Http.Json;
using ChatService.Models;
//using CommonModels.Models;
using SharedServices.Models;

public class ChatHttpClientService
{
    private readonly HttpClient _http;
    private readonly IHttpContextAccessor _context;

    public ChatHttpClientService(HttpClient http, IHttpContextAccessor context)
    {
        _http = http;
        _context = context;
    }

    // ✅ Get full conversation between two users
    public async Task<List<ChatMessage>> GetConversationAsync(string user1, string user2)
    {
        var token = _context.HttpContext?.Request.Headers["Authorization"].ToString()?.Replace("Bearer ", "");
        if (!string.IsNullOrWhiteSpace(token))
        {
            _http.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
        }

        var url = $"http://localhost:5076/api/chat/conversation?user1={user1}&user2={user2}";

        var response = await _http.GetAsync(url);
        if (!response.IsSuccessStatusCode)
        {
            return new List<ChatMessage>();
        }

        return await response.Content.ReadFromJsonAsync<List<ChatMessage>>() ?? new List<ChatMessage>();
    }
}