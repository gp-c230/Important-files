﻿using AutoMapper;
using StudentService.Models;

namespace StudentService.Mappings
{
    public class StudentProfile : Profile
    {
        public StudentProfile()
        {
            CreateMap<Student, Student>().ReverseMap();
        }
    }
}
