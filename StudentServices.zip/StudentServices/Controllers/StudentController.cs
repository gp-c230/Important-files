﻿
using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SharedServices.Models;
using StudentService.Data;
using StudentService.Data.Interfaces;
using StudentService.Models;
using System;
using System.Security.Claims;

namespace StudentService.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class StudentController : ControllerBase
    {
        private readonly IStudentRepository _repo;
        private readonly IMapper _mapper;
        private readonly StudentDbContext _context;
        private readonly ChatHttpClientService _chatHttpClientService;

        public StudentController(IStudentRepository repo, IMapper mapper, StudentDbContext context, ChatHttpClientService chat)
        {
            _repo = repo;
            _mapper = mapper;
            _context = context;
            _chatHttpClientService = chat;

        }

        [HttpPost("register")]
        public async Task<IActionResult> Register(Student dto)
        {
            var student = _mapper.Map<Student>(dto);
            student.Status = Status.Pending;
            await _repo.AddAsync(student);
            await _repo.SaveAsync();
            return Ok(new { message = "Student registered and pending approval." });
        }

        [HttpGet("All-Students")]

        public async Task<IActionResult> GetAll()
        {
            var students = await _repo.GetAllAsync();
            return Ok(_mapper.Map<IEnumerable<Student>>(students));
        }

        [HttpGet("{email}")]
        public async Task<IActionResult> GetByEmail(string email)
        {
            var student = await _repo.GetByEmailAsync(email);
            if (student == null) return NotFound();
            return Ok(_mapper.Map<Student>(student));
        }
        [HttpGet("pending")]
        public async Task<IActionResult> GetPendingStudents()
        {
            var students = await _context.Students
            .Where(s => s.Status == Status.Pending)
            .ToListAsync();

            return Ok(students);
        }
        [HttpPost]
        public async Task<IActionResult> CreateStudent(StudentDto dto)
        {
            var student = _mapper.Map<Student>(dto);
            _context.Students.Add(student);
            await _context.SaveChangesAsync();
            return Ok(student);
        }

        //[Authorize(Roles = "Admin")]
        [HttpPut("approve/{id}")]
        public async Task<IActionResult> ApproveStudent(int id)
        {
            try
            {
                var student = await _context.Students.FindAsync(id);
                if (student == null)
                    return NotFound("Student not found");

                student.Status = Status.Approved;
                await _context.SaveChangesAsync();
                return Ok("Student approved");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error approving student: {ex.Message}");
            }
        }

        [Authorize(Roles = "Student")]
        [HttpGet("conversation")]
        public async Task<IActionResult> GetConversationWithUserId([FromQuery] string withUserId)
  
        {
            var currentUserId = User.FindFirst(ClaimTypes.Email)?.Value;

            if (string.IsNullOrWhiteSpace(currentUserId))
                return Unauthorized();

            var messages = await _chatHttpClientService.GetConversationAsync(currentUserId, withUserId);
            return Ok(messages);
        }


        [Authorize(Roles = "Admin")]
        [HttpPut("/internal/student/approve/{id}")]
        public async Task<IActionResult> ApproveStudentUser(int id)
        {
            var student = await _context.Students.FindAsync(id);
            if (student == null) return NotFound();

            student.Status = Status.Approved;
            await _context.SaveChangesAsync();

            return Ok("Student approved in StudentService.");
        }
    }
}
