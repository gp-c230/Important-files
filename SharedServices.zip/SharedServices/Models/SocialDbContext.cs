﻿using SharedServices.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;

namespace SharedServices.Models
{
    public class SocialDbContext : DbContext
    {
        public SocialDbContext()
        {
        }
        public SocialDbContext(DbContextOptions<SocialDbContext> options) : base(options)
        {

        }
        public virtual DbSet<StudentDto> Students { get; set; }
        public virtual DbSet<PostDTO> Posts { get; set; }
        public virtual DbSet<FacultyDto> Faculties { get; set; }
        public virtual DbSet<EventDto> Events { get; set; }
        
    
    //protected override void OnModelCreating(ModelBuilder modelBuilder)
    //    {
    //        modelBuilder.Entity<EventDto>().HasNoKey();

    //        base.OnModelCreating(modelBuilder);
    //    }
    }
}


