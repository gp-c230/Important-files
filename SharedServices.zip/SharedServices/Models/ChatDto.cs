﻿namespace CommonModels.Models
{
    public class ChatDTO
    {
        public int Id { get; set; }                  // Optional for creation; required for DB mapping
        public string SenderId { get; set; } = "";   // UserId or StudentId
        public string ReceiverId { get; set; } = ""; // Optional (for private messages); leave empty for broadcast
        public string Message { get; set; } = "";    // Actual message content
        public DateTime Timestamp { get; set; } = DateTime.UtcNow;
        public string SenderRole { get; set; } = ""; // e.g., "Student", "Admin", "Faculty" (optional if needed for filtering)
    }
}