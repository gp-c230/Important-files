﻿using System.ComponentModel.DataAnnotations;

namespace SharedServices.Models
{
    public class EventDto
    {
        [Key]
        public int EventId { get; set; }
        public string Title { get; set; } = "";
        public string Details { get; set; } = "";
        public int CreatedByStaffId { get; set; }
        public DateTime Date { get; set; }
    }
}
