﻿namespace SharedServices.Models
{
    public enum Status
    {
        Pending,
        Approved,
        Rejected
    }
}
