﻿namespace SharedServices.Models
{
    public class PlacementDto
    {
        public int PlacementId { get; set; }
        public string CompanyName { get; set; } = "";
        public string Role { get; set; } = "";
        public int CTC { get; set; }
        public DateTime LastDateToApply { get; set; }
        public Status status { get; set; }
    }
}
