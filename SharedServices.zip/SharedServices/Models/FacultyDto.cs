﻿using System.ComponentModel.DataAnnotations;

namespace SharedServices.Models
{
    public class FacultyDto
    {
        [Key]
        public int FacultyId { get; set; }
        public string Name { get; set; } = "";
        public string Department { get; set; } = "";
    }
}
