﻿using System;
namespace SharedServices.Models
{
    public enum PostStatus { Pending, Approved, Rejected }

    public class PostDTO
    {
        public int Id { get; set; }
        public string Title { get; set; } = "";
        public string Content { get; set; } = "";
        public string Author { get; set; } = "";
        public PostStatus Status { get; set; }
    }
}