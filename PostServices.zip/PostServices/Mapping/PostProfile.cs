﻿using AutoMapper;
using PostService.Models;

namespace PostService.Mappings
{
    public class PostProfile : Profile
    {
        public PostProfile()
        {
            CreateMap<Post, Post>().ReverseMap();
        }
    }
}