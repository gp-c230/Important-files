﻿using SharedServices.Models;
using Microsoft.EntityFrameworkCore;
using PostService.Data.Interfaces;
using PostService.Models;
using SharedServices.Models;

namespace PostService.Data.Repositories
{
    public class PostRepository : IPostRepository
    {
        private readonly PostDbContext _context;

        public PostRepository(PostDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Post>> GetAllAsync() => await _context.Posts.ToListAsync();

        public async Task<Post?> GetByIdAsync(int id) => await _context.Posts.FindAsync(id);

        public async Task AddAsync(Post post) => await _context.Posts.AddAsync(post);

        public async Task UpdateAsync(Post post)
        {
            _context.Posts.Update(post);
            await SaveAsync();
        }

        public async Task SaveAsync() => await _context.SaveChangesAsync();

        //public Task<Post> UpdatePostStatusAsync(int id, PostStatus status)
        //{
        //    throw new NotImplementedException();
        //}

        public async Task<Post> UpdatePostStatusAsync(int id, PostStatus status)
        {
            var post = await _context.Posts.FindAsync(id);
            if (post == null) return null;

            post.Status = status;
            await _context.SaveChangesAsync();
            return post;
        }
    }
}
