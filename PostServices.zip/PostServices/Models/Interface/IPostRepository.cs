﻿using SharedServices.Models;
using PostService.Models;
using SharedServices.Models;

namespace PostService.Data.Interfaces
{
    public interface IPostRepository
    {

        Task<Post> UpdatePostStatusAsync(int id, PostStatus status);
        Task<IEnumerable<Post>> GetAllAsync();
        Task<Post?> GetByIdAsync(int id);
        Task AddAsync(Post post);
        Task UpdateAsync(Post post);
        Task SaveAsync();
    }
}