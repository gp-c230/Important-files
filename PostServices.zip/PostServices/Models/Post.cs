﻿using SharedServices.Models;

namespace PostService.Models
{
    public class Post
    {
        public int Id { get; set; }
        public string Title { get; set; } = "";
        public string Content { get; set; } = "";
        public string Author { get; set; } = "";
        public PostStatus Status { get; set; } = PostStatus.Pending;
    }
}
