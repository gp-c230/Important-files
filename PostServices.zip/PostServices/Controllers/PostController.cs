﻿using AutoMapper;
using SharedServices.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PostService.Data.Interfaces;
using PostService.Data.Repositories;
using PostService.Models;
using SharedServices.Models;

namespace PostService.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class PostController : ControllerBase
    {
        private readonly IPostRepository _repo;
        private readonly IMapper _mapper;

        public PostController(IPostRepository repo, IMapper mapper)
        {
            _repo = repo;
            _mapper = mapper;
        }

        [Authorize(Roles ="Student,Faculty")]
        [HttpPost("Create-post")]
        public async Task<IActionResult> CreatePost(Post dto)
        {
            var post = _mapper.Map<Post>(dto);
            post.Status = SharedServices.Models.PostStatus.Pending;
            await _repo.AddAsync(post);
            await _repo.SaveAsync();
            return Ok("Post submitted for approval.");
        }

        [HttpGet("posts")]
        public async Task<IActionResult> GetAll()
        {
            var posts = await _repo.GetAllAsync();
            var approvedPosts = posts.Where(p => p.Status == PostStatus.Approved);
            return Ok(_mapper.Map<IEnumerable<Post>>(approvedPosts));
        }

        [HttpGet("pending-posts")]
        public async Task<IActionResult> GetPendingPosts()
        {
            var posts = await _repo.GetAllAsync();
            var pendingPosts = posts.Where(p => p.Status == PostStatus.Pending);
            return Ok(_mapper.Map<IEnumerable<Post>>(pendingPosts));
        }



        [Authorize(Roles ="Admin")]
        [HttpPut("approve/{id}")]
        public async Task<IActionResult> ApprovePost(int id, [FromQuery] string status)
        {
            if (!Enum.TryParse<PostStatus>(status, true, out var parsedStatus))
            {
                return BadRequest("Invalid status value.");
            }

            var updated = await _repo.UpdatePostStatusAsync(id, parsedStatus);
            if (updated == null) return NotFound("Post not found");

            return Ok(updated);
        }
    }
}
