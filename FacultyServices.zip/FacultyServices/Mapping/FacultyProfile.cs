﻿using AutoMapper;
using FacultyService.Models;

namespace FacultyService.Mappings
{
    public class FacultyProfile : Profile
    {
        public FacultyProfile()
        {
            CreateMap<Faculty, Faculty>().ReverseMap();
        }
    }
}