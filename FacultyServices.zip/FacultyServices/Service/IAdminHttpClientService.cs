﻿// Interfaces/IAdminHttpClientService.cs
using FacultyService.Models;

public interface IAdminHttpClientService
{
    Task<bool> IsAdminAuthorizedAsync(string token);
    Task<IEnumerable<Faculty>> GetAllFacultiesFromAdminAsync(string token);
}