﻿// Services/AdminHttpClientService.cs
using FacultyService.Models;
using System.Net.Http.Headers;

public class AdminHttpClientService : IAdminHttpClientService
{
    private readonly HttpClient _httpClient;
    private readonly IConfiguration _configuration;

    public AdminHttpClientService(HttpClient httpClient, IConfiguration configuration)
    {
        _httpClient = httpClient;
        _configuration = configuration;
    }

    public async Task<bool> IsAdminAuthorizedAsync(string token)
    {
        var request = new HttpRequestMessage(HttpMethod.Get, "http://localhost:5070/api/admin/verify");
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);

        var response = await _httpClient.SendAsync(request);
        return response.IsSuccessStatusCode;
    }

    public async Task<IEnumerable<Faculty>> GetAllFacultiesFromAdminAsync(string token)
    {
        var request = new HttpRequestMessage(HttpMethod.Get, "http://localhost:5070/api/admin/faculties");
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);

        var response = await _httpClient.SendAsync(request);
        if (!response.IsSuccessStatusCode) return new List<Faculty>();

        return await response.Content.ReadFromJsonAsync<List<Faculty>>();
    }

    Task<IEnumerable<Faculty>> IAdminHttpClientService.GetAllFacultiesFromAdminAsync(string token)
    {
        throw new NotImplementedException();
    }
}