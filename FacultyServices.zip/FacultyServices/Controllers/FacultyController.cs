﻿using AutoMapper;
using FacultyService.Data.Interfaces;
using FacultyService.Models;
using Microsoft.AspNetCore.Mvc;

namespace FacultyService.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class FacultyController : ControllerBase
    {
        private readonly IFacultyRepository _repo;
        private readonly IMapper _mapper;
        private readonly IAdminHttpClientService _adminClient;

        public FacultyController(IFacultyRepository repo, IMapper mapper, IAdminHttpClientService adminClient)
        {
            _repo = repo;
            _mapper = mapper;
            _adminClient = adminClient;
        }


        

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var faculties = await _repo.GetAllAsync();
            return Ok(_mapper.Map<IEnumerable<Faculty>>(faculties));
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var faculty = await _repo.GetByIdAsync(id);
            if (faculty == null) return NotFound("Faculty not found.");
            return Ok(_mapper.Map<Faculty>(faculty));
        }

        [HttpPost]
        public async Task<IActionResult> Add(Faculty dto)
        {
            var faculty = _mapper.Map<Faculty>(dto);
            await _repo.AddAsync(faculty);
            await _repo.SaveAsync();
            return Ok("Faculty added.");
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, Faculty dto)
        {
            var faculty = await _repo.GetByIdAsync(id);
            if (faculty == null) return NotFound("Faculty not found.");
            dto.FacultyId = id;

            _mapper.Map(dto, faculty);
            await _repo.UpdateAsync(faculty);
            await _repo.SaveAsync();
            return Ok("Faculty updated.");
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var faculty = await _repo.GetByIdAsync(id);
            if (faculty == null) return NotFound("Faculty not found.");

            await _repo.DeleteAsync(faculty);
            await _repo.SaveAsync();
            return Ok("Faculty deleted.");
        }


        [HttpGet("from-admin")]
        public async Task<IActionResult> GetFaculties()
        {
            var token = HttpContext.Request.Headers["Authorization"].ToString().Replace("Bearer ", "");

            var isAuthorized = await _adminClient.IsAdminAuthorizedAsync(token);
            if (!isAuthorized) return Unauthorized("Invalid Admin Token");

            var faculties = await _adminClient.GetAllFacultiesFromAdminAsync(token);
            return Ok(faculties);
        }
    }
}