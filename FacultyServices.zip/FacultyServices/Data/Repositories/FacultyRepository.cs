﻿using FacultyService.Data.Interfaces;
using FacultyService.Models;
using Microsoft.EntityFrameworkCore;

namespace FacultyService.Data.Repositories
{
    public class FacultyRepository : IFacultyRepository
    {
        private readonly FacultyDbContext _context;

        public FacultyRepository(FacultyDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Faculty>> GetAllAsync()
            => await _context.Faculties.ToListAsync();

        public async Task<Faculty?> GetByIdAsync(int id)
            => await _context.Faculties.FindAsync(id);

        public async Task AddAsync(Faculty faculty)
            => await _context.Faculties.AddAsync(faculty);

        public async Task UpdateAsync(Faculty faculty)
        {
            _context.Faculties.Update(faculty);
        }

        public async Task DeleteAsync(Faculty faculty)
        {
            _context.Faculties.Remove(faculty);
        }

        public async Task SaveAsync() => await _context.SaveChangesAsync();
    }
}