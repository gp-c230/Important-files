﻿using Microsoft.EntityFrameworkCore;
using FacultyService.Models;

namespace FacultyService.Data
{
    public class FacultyDbContext : DbContext
    {
        public FacultyDbContext(DbContextOptions<FacultyDbContext> options) : base(options) { }

        public DbSet<Faculty> Faculties { get; set; }
    }
}