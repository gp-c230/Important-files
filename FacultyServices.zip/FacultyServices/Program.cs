using Microsoft.EntityFrameworkCore;
using FacultyService.Data;
using FacultyService.Data.Interfaces;
using FacultyService.Data.Repositories;
using FacultyService.Mappings;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();
builder.Services.AddDbContext<FacultyDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));
builder.Services.AddScoped<IFacultyRepository, FacultyRepository>();
builder.Services.AddHttpClient<IAdminHttpClientService, AdminHttpClientService>();
builder.Services.AddAutoMapper(typeof(FacultyProfile));
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

app.UseSwagger();
app.UseSwaggerUI();
app.UseHttpsRedirection();
app.MapControllers();
app.Run();
